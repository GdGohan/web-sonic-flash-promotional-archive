<?php
/**
 * This PHP script returns screenshot and video feeds for the full M&S Winter site
 * @author  David Felton 
 * 
 */

require_once('../../../../classes/DatabaseUtils.class.php');
require_once('../../../../classes/SegaWestUtils.class.php');
require_once('../../../../classes/ScreenshotUtils.class.php');
require_once('../../../../classes/VideoUtils.class.php');
require_once('../../../../classes/CategoryUtils.class.php');
require_once('../../../../classes/TerritoryUtils.class.php');

//define('GAMEGROUPID',31);//empire
define('GAMEGROUPID',174);//M&S winter

// Check on their territory...
//$territoryid = TerritoryUtils::getTerritoryByName($_COOKIE['ms_sega_preferred_territory']);
//define('TERRITORYID',$territoryid->getID());
if (is_numeric($_GET['tid'])) {
	$territoryid = $_GET['tid'];
} else {
    $territoryid = 2;
}

//variable to hold XML
$out = '<'.'?xml version="1.0" ?'.'>';

//do we want to retrieve screenshots?
if($_GET['content']=='screenshots') {
	//wrap the XML in screenshot tag
	$out .='<screenshots>';
	/**
	 * This are the screenshot categories defined for M&S Winter
	 * 
<?xml version="1.0" ?><screenshots><category id="62" name="Alpine Skiing" />
<category id="64" name="Bobsleigh" />
<category id="69" name="Figure Skating" />
<category id="72" name="Homepage" />
<category id="63" name="Ice Hockey" />
<category id="68" name="Moguls" />
<category id="75" name="Nintendo DS Experience Features" />
<category id="67" name="Skeleton" />
<category id="70" name="Ski Jump" />
<category id="66" name="Snowboard Cross" />
<category id="65" name="Snowboard Halfpipe" />
<category id="61" name="Speed Skating" />
<category id="76" name="Wii Experience Features" />
</screenshots>
	 */
	
	//is there a category ID specified?
	if(is_numeric($_GET['categoryid'])) {
		//return the screenhots for the specified category
		$screenshot_ar = ScreenshotUtils::getScreenshots(GAMEGROUPID,//$gamegroupid
		                                                 '',//$gameplatformid
		                                                 '',//$image_name
		                                                 $territoryid,//$territoryid
		                                                 'ci.categoryid, s.date DESC',//$orderby
		                                                 '',//$start
						    							 '',//$limit
		                                                 false,//$uniquepergame
		                                                 false,//$showFromHiddenGames
		                                                 true,//$showFuture - THIS IS TEMP
		                                                 (is_numeric($_GET['platformid']) ? 
		                                                      $_GET['platformid'] : ''),
						    							 $_GET['categoryid']);

		//check there are some screen for this category before we go any further
		if(count($screenshot_ar)>0) {
			//grab the category
			$category = CategoryUtils::getCategory($_GET['categoryid']);
			$out .='<category id="'.$category->getID().'" name="'.$category->getTitle().'">';

			foreach($screenshot_ar as $screenshot) {
				$out.='<item id="'.$screenshot->getID().'"';
				$out.=' small="http://www.sega.com'.
				    ScreenshotUtils::getThumbnailLocationFrontend().$screenshot->getImage1().'"';
				$out.=' medium="http://www.sega.com'.
				    ScreenshotUtils::getThumbnailLocationFrontend().$screenshot->getImage2().'"';
				
				if(file_exists('http://www.sega.com'.
				    ScreenshotUtils::getThumbnailLocationFrontend().$screenshot->getImage3())) {
					$out.=' large="http://www.sega.com'.
					   ScreenshotUtils::getThumbnailLocationFrontend().
					   $screenshot->getImage3().'" />'."\n";
				} else {
					$out.=' large="http://www.sega.com'.
					   ScreenshotUtils::getThumbnailLocationFrontend().
					   $screenshot->getImage2().'" />'."\n";
				}
			}
			$out .='</category>';
		}
		
	} else {
		//no category specified so we return all screens for this game irrespective of category
        $screenshot_ar = ScreenshotUtils::getScreenshots(GAMEGROUPID,//$gamegroupid
                                                         '',//$gameplatformid
                                                         '',//$image_name
                                                         $territoryid,//$territoryid
                                                         's.date DESC',//$orderby
                                                         '',//$start
                                                         '',//$limit
                                                         false,//$uniquepergame
                                                         false,//$showFromHiddenGames
                                                         true,//$showFuture - THIS IS TEMP
                                                         (is_numeric($_GET['platformid']) ? 
                                                            $_GET['platformid'] : ''));

        //check there are some screen for this category before we go any further
        if(count($screenshot_ar)>0) {
            $out .='<category>';
            foreach($screenshot_ar as $screenshot) {
                $out.='<item id="'.$screenshot->getID().'"';
                $out.=' small="http://www.sega.com'.
                    ScreenshotUtils::getThumbnailLocationFrontend().$screenshot->getImage1().'"';
                $out.=' medium="http://www.sega.com'.
                    ScreenshotUtils::getThumbnailLocationFrontend().$screenshot->getImage2().'"';
                
                if(file_exists('http://www.sega.com'.
                    ScreenshotUtils::getThumbnailLocationFrontend().$screenshot->getImage3())) {
                    $out.=' large="http://www.sega.com'.
                        ScreenshotUtils::getThumbnailLocationFrontend().
                        $screenshot->getImage3().'" />'."\n";
                } else {
                    $out.=' large="http://www.sega.com'.
                        ScreenshotUtils::getThumbnailLocationFrontend().
                        $screenshot->getImage2().'" />'."\n";
                }
            }
            $out .='</category>';
        }
		/*		
		//no category specified so we just return a list of categories
		$categories_ar = CategoryUtils::getCategories(2, //category type is screenshots
		                                              '', 
		                                              GAMEGROUPID, 
		                                              2);//territory ID is hardcoded for now

		foreach($categories_ar as $category) {
			$out .='<category id="'.$category->getID().'" name="'.$category->getTitle().'" />'."\n";
		}		
        */
	}
	$out .='</screenshots>';

} else {
	//assume we want videos
	
    /**
     * This are the video categories defined for M&S Winter
     * 	
<?xml version="1.0" ?><videos><category id="52" name="Alpine Skiing" />
<category id="54" name="Bobsleigh" />
<category id="59" name="Figure Skating" />
<category id="50" name="Homepage" />
<category id="53" name="Ice Hockey" />
<category id="58" name="Moguls" />
<category id="73" name="Nintendo DS Experience Features" />
<category id="57" name="Skeleton" />
<category id="60" name="Ski Jump" />
<category id="56" name="Snowboard Cross" />
<category id="55" name="Snowboard Halfpipe" />
<category id="51" name="Speed Skating" />
<category id="74" name="Wii Experience Features" />
</videos>	
    */
	
	//wrap the XML in screenshot tag
	$out .='<videos>';
	//is there a category ID specified?
	if(is_numeric($_GET['categoryid'])) {
        //return the videos for the specified category
        $videos_ar = VideoUtils::getVideos(GAMEGROUPID,//$gamegroupid
                                           '',//$gameplatformid
                                           '',//$image_name
                                           '',//$video_name
                                           $territoryid,//$territoryid
                                           'ci.categoryid, s.date DESC',//$orderby
                                           '',//$start
                                           '',//$limit
                                           false,//$showFromHiddenGames
                                           false,//$onbackend
                                           true,//$showFuture - THIS IS TEMP
                                           false,//$onmicrosite
                                           (is_numeric($_GET['platformid']) ? 
                                                $_GET['platformid'] : ''),
                                           $_GET['categoryid']);
//error_log("VideoUtils::getVideos(".GAMEGROUPID.",'','',".TERRITORYID.",'ci.categoryid, s.date DESC','','',false,false,true,".(is_numeric($_GET['platformid']) ? $_GET['platformid'] : '').",".$_GET['categoryid'].")");
                                           
        
        //check there are some screen for this category before we go any further
        if(count($videos_ar)>0) {
            //grab the category
            $category = CategoryUtils::getCategory($_GET['categoryid']);
            $out .='<category id="'.$category->getID().'" name="'.$category->getTitle().'">';

            foreach($videos_ar as $video) {
                $out.='<item id="'.$video->getID().'"';
                $out.=' heading="'.$video->getTitle('en').'"';
                $out.=' thumb="http://www.sega.com'.
                    VideoUtils::getThumbnailLocationFrontend().$video->getImage1().'"';
                $out.=' url="'.
                    VideoUtils::getStreamingServer(false, $video->getUploadTime()).
                    $video->getVideo().'" />'."\n";
            }
            $out .='</category>';
        }
	} else {
        //no category specified so we return all videos for this game irrespective of category
        $videos_ar = VideoUtils::getVideos(GAMEGROUPID,//$gamegroupid
                                           '',//$gameplatformid
                                           '',//$image_name
                                           '',//$video_name
                                           $territoryid,//$territoryid
                                           's.date DESC',//$orderby
                                           '',//$start
                                           '',//$limit
                                           false,//$showFromHiddenGames
                                           false,//$onbackend
                                           true,//$showFuture - THIS IS TEMP
                                           false,//$onmicrosite
                                           (is_numeric($_GET['platformid']) ? 
                                                $_GET['platformid'] : ''));
        
        //check there are some screen for this category before we go any further
        if(count($videos_ar)>0) {
            $out .='<category>';
            foreach($videos_ar as $video) {
                $out.='<item id="'.$video->getID().'"';
                $out.=' heading="'.$video->getTitle('en').'"';
                $out.=' thumb="http://www.sega.com'.
                    VideoUtils::getThumbnailLocationFrontend().$video->getImage1().'"';
                $out.=' url="'.
                    VideoUtils::getStreamingServer(false, $video->getUploadTime()).
                    $video->getVideo().'" />'."\n";
            }
            $out .='</category>';
        }
        
		/*
		//no category specified so we just return a list of categories
        $categories_ar = CategoryUtils::getCategories(3, //category type is videos
                                                      '', 
                                                      GAMEGROUPID, 
                                                      2);//territory ID is hardcoded for now

        foreach($categories_ar as $category) {
            $out .='<category id="'.$category->getID().'" name="'.$category->getTitle().'" />'."\n";
        }   
        */
	}
	$out .='</videos>';
}
echo $out;

?>